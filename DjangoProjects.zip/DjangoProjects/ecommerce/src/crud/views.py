from django.shortcuts import render

# Create your views here.
def home_screen_view(request):
       
       #context = {}
      #context['some_string'] = " More stuff to write using context"
      # context['some_digits'] = 1234567890


     context = {

              'some_string': " More stuff to write using context",
              'some_digits':444444444445555555555558889123456789
     }


     return render(request,"crud/home.html", context)